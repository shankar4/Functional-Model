//============================================================================
// Name        : monitor.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Full Adder in SystemC,  Ansi-style
//============================================================================


#include <iostream>
using namespace std;
// All Systemc modules should include systemc.h header file
#include "systemc.h"

// full_adder is the module name
// Example from Bhasker, A SystemC Primer


// File: monitor.h
#include "systemc.h"
SC_MODULE (monitor){
	sc_in<bool> m_a, m_b, m_cin, m_sum, m_cout;
	void prc_monitor ();

	SC_CTOR (monitor) {
		SC_METHOD (prc_monitor);
		sensitive << m_a << m_b << m_cin <<m_sum << m_cout;
	}
};



