//============================================================================
// Name        : driver.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Full Adder in SystemC,  Ansi-style
//============================================================================


#include <iostream>
using namespace std;
// All Systemc modules should include systemc.h header file
#include "systemc.h"

// full_adder is the module name
// Example from Bhasker, A SystemC Primer


//  File: driver.cpp
#include "driver.h"

void driver::prc_driver() {
	sc_uint<3> pattern;
	pattern = 0;

	while (1) {
		d_a = pattern[0];
		d_b = pattern[1];
		d_cin = pattern[2];
		wait (5, SC_NS);
		pattern++;
	}
}



