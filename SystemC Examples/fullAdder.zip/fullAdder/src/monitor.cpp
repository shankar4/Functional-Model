//============================================================================
// Name        : monitor.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Full Adder in SystemC,  Ansi-style
//============================================================================


#include <iostream>
using namespace std;
// All Systemc modules should include systemc.h header file
#include "systemc.h"

// full_adder is the module name
// Example from Bhasker, A SystemC Primer



//File: monitor.cpp
#include "monitor.h"

void monitor::prc_monitor () {
	cout << "At time "<< sc_time_stamp() << "::";
	cout << "(a, b, carry_in):";
	cout << m_a << m_b << m_cin;
	cout << " (sum, carry_out):" << m_sum << m_cout << endl;
}



