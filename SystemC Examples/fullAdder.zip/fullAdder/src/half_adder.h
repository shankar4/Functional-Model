//============================================================================
// Name        : half_adder.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Full Adder in SystemC,  Ansi-style
//============================================================================


#include <iostream>
using namespace std;
// All systemc modules should include systemc.h header file
#include "systemc.h"

// half_adder is the module name
// Example from Bhasker, A SystemC Primer
// File: half_adder.h


SC_MODULE (half_adder) {
	sc_in<bool> a, b;
	sc_out<bool> sum, carry;

	void prc_half_adder ();

	SC_CTOR (half_adder) {
		SC_METHOD (prc_half_adder);
		sensitive << a << b;
	}
};

