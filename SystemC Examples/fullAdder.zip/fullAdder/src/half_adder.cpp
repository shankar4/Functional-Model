//============================================================================
// Name        : half_adder.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Full Adder in SystemC,  Ansi-style
//============================================================================


#include <iostream>
using namespace std;
// All systemc modules should include systemc.h header file
#include "systemc.h"

// half_adder is the module name
// Example from Bhasker, A SystemC Primer

// File: half_adder.cpp
# include "half_adder.h"

void half_adder::prc_half_adder() {
	sum = a ^ b;
	carry = a & b;
}
