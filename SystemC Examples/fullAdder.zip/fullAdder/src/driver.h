//============================================================================
// Name        : driver.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Full Adder in SystemC,  Ansi-style
//============================================================================


#include <iostream>
using namespace std;
// All Systemc modules should include systemc.h header file
#include "systemc.h"

// full_adder is the module name
// Example from Bhasker, A SystemC Primer

// File: driver.h
SC_MODULE (driver) {
	sc_out<bool> d_a, d_b, d_cin;
	void prc_driver();
	SC_CTOR (driver){
		SC_THREAD (prc_driver);
	}
};





