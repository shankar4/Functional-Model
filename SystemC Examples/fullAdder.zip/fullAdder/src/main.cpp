//============================================================================
// Name        : monitor.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Full Adder in SystemC,  Ansi-style
//============================================================================


#include <iostream>
using namespace std;
// All Systemc modules should include systemc.h header file
#include "systemc.h"

// full_adder is the module name
// Example from Bhasker, A SystemC Primer


// File: full_adder_main.cpp

#include "driver.h"
#include "monitor.h"
#include "full_adder.h"

int sc_main (int argc, char* argv[]) {
	sc_signal<bool> t_a, t_b, t_cin, t_sum, t_cout;
	full_adder f1 ("FullAdderWithHalfAdder");
	// connect using positional association:
	f1 <<t_a << t_b << t_cin << t_sum << t_cout;
	driver d1 ("GenerateWaveforms");
	// connect using named association:
	d1.d_a(t_a);
	d1.d_b(t_b);
	d1.d_cin(t_cin);

	monitor m01 ("MonitorWaveforms");
	m01 << t_a << t_b << t_cin<< t_sum << t_cout;
	sc_start(100, SC_NS);
	return(0);
}

