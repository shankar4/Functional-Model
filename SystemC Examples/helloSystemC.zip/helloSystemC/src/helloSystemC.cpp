//============================================================================
// Name        : helloSystemC.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

//==========================================================================
// Name : Hello.cpp
// Author :
// Version :
// Copyright : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
// All systemc modules should include systemc.h header file
#include "systemc.h"
// Hello_world is module name


SC_MODULE (helloworld) {
SC_CTOR (helloworld) {
// Nothing in constructor
	}
void sayhello() {
//Print "Hello SystemC" to the console.
cout << "Hello SystemC.\n";
	}
};

// sc_main in top level function like in C++ main
int sc_main(int argc, char* argv[]) {
helloworld hello("HELLO");
// Print the hello world
hello.sayhello();
printf("Hello");
return(0);
}
