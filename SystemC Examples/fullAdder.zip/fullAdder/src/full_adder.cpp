//============================================================================
// Name        : full_adder.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Full Adder in SystemC,  Ansi-style
//============================================================================


#include <iostream>
using namespace std;
// All systemc modules should include systemc.h header file
#include "systemc.h"

// full_adder is the module name
// Example from Bhasker, A SystemC Primer


// File: full_adder.cpp
# include "full_adder.h"

void full_adder::prc_or() {
	carry_out = c1 | c2;
}
